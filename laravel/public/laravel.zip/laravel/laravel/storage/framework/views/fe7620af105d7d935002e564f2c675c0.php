<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nyanya wrapper login-title">
    <h1 class="sub-title">ログイン画面</h1>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST"action="/login">
        <?php echo csrf_field(); ?>
        <div>
            <label for="email" class="login-form">メールアドレス</label>
            <input name="email" type="email" value="<?php echo e(old('email')); ?>" class="c-form-text"/>
        </div>
        <div>
            <label for="password" class="login-form">パスワード</label>
            <input name="password" type="password" class="c-form-text" class="c-form-text"/>
        </div>
        <div>
            <button type="submit" >送信</button>
        </div>
    </form>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\laravel\resources\views/login.blade.php ENDPATH**/ ?>