<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nyanya wrapper">
    <?php if(auth()->guard()->check()): ?>
    <h3 class="welcome-messeage">ようこそ<?php echo e(Auth::user()->name); ?>さん！ intel最高だよな？</h3>
    <?php endif; ?>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\laravel\resources\views/home.blade.php ENDPATH**/ ?>