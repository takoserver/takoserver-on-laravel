<?php echo $__env->make("common.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nyanya wrapper login-title">
    <h1>ログアウトしますか？</h1>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">ログアウト</button>
    </form>
</div>
<?php echo $__env->make("common.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\laravel\resources\views/logout.blade.php ENDPATH**/ ?>