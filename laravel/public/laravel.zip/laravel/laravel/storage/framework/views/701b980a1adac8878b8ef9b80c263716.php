<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nyanya wrapper">
    <h3 class="sub-title">プライバシーポリシー</h3>
    <p>
        takoserverは，ユーザーの個人情報について以下のとおりプライバシーポリシー（以下、「本ポリシー」という。）を定めます。本ポリシーは、当社がどのような個人情報を取得し、どのように利用・共有するか、ユーザーがどのようにご自身の個人情報を管理できるかをご説明するものです。
    </p>
    <h3 class="sub-title">プライバシーポリシー</h3>
    <p>

    </p>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\laravel\resources\views/privacypolicy.blade.php ENDPATH**/ ?>