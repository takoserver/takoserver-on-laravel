@include('common.header')
<div class="nyanya wrapper">
    <h3 class="sub-title">プライバシーポリシー</h3>
    <p>
        takoserverは，ユーザーの個人情報について以下のとおりプライバシーポリシー（以下、「本ポリシー」という。）を定めます。本ポリシーは、当社がどのような個人情報を取得し、どのように利用・共有するか、ユーザーがどのようにご自身の個人情報を管理できるかをご説明するものです。
    </p>
    <h3 class="sub-title">プライバシーポリシー</h3>
    <p>

    </p>
</div>
@include('common.footer')