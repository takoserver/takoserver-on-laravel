<footer>
    <div class="footer-m">
        <p><small>Copyright &copy; 2022-2023 Tomiyama Shota All Rights Reserved.</small></p>
        <a href="./privacypolicy" class="footer-a">プライバシーポリシー</a>
    </div>
</footer>
</html>