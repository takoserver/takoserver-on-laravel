@include('common.header')
@yield('main')
@include('common.footer')